<?php 

return [
    'change_return' => 'Farklı şubede iade etmek istiyorum',
    'weekend_rule' => ':pickup_station ofisi :pickup_day günü alış :return_day bırakış olarak :rent_day gün kiralama yapabilirsiniz!',
];