<?php 

return [
    'pazartesi' => 'Pazartesi',
    'sali' => 'Salı',
    'carsamba' => 'Çarşamba',
    'persembe' => 'Perşembe',
    'cuma' => 'Cuma',
    'cumartesi' => 'Cumartesi',
    'pazar' => 'Pazar',
];