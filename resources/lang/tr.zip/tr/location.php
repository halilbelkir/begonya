<?php 

return [
    'best_deals' => 'En İyi Teklifler',
    'best_deals_detail' => 'Günlük Ortalama Kiralama Ücreti',
];