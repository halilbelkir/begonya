<?php 

return [
    'turkiyede_arac_kiralama' => 'Türkiye Araç Kiralama',
    'fiyat_hesapla' => 'FİYATI HESAPLA',
    'alis' => 'Alış',
    'donus' => 'Dönüş',
    'hosgeldiniz' => 'İstasyonumuza Hoşgeldiniz',
    'genel_bilgiler' => 'İstasyon Hakkında Genel Bilgiler',
    'acilis_kapanis_saatleri' => 'Açılış / Kapanış Saatleri',
    'haftaici' => 'Hafta içi',
    'haftasonu' => 'Hafta sonu',
    'cumartesi' => 'Cumartesi',
    'pazar' => 'Pazar',
    'iletisim_bilgileri' => 'İletişim Bilgileri',
    'alis_donus_bilgileri' => 'Alış / Dönüş Bilgileri',
    'bilgi_servisi' => 'Bilgi Servisi',
    'sube' => 'Şube',
    'book_now_station' => 'Bu İstasyondan Araç Kirala',
    'telefon' => 'Telefon',
    'address' => 'Adres',
    'email' => 'E-Posta',
    'station_close' => 'Kapalı',
    'page_home' => 'Anasayfa',
    'station_index_bredcump' => 'kiralama-noktalari'
];