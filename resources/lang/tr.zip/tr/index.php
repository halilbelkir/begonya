<?php 

return [
    'orta_bolum_baslik' => 'ARADIĞINIZ ARACI DÜNYANIN HER YERİNDE KİRALAYIN',
    'resim_1_yazi' => 'KİRALAMA NOKTALARI',
    'resim_2_yazi' => 'FIRSATLAR',
    'resim_3_yazi' => 'ARAÇ FİLOMUZ',
    'kampanya_baslik' => 'ÖNE ÇIKAN KAMPANYALAR',
    'rez_yap' => 'REZERVASYON YAP',
    'uzun_kiralama' => '30 günden uzun kiralamalar için lütfen müşteri hizmetlerini arayınız.',
    'tekyonhata' => 'Seçtiğiniz istasyonlar arasında tek yönlü kiralama mevcut değildir.',
    'box_discount' => 'ONLİNE ÖDEMEDE %30 İNDİRİM',
    'campaigns' => 'Kampanyalar',
    'popular_locations' => 'POPÜLER LOKASYONLAR',
];