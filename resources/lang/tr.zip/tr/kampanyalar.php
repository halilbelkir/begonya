<?php 

return [
    'tumunu_gor' => 'Tümünü Gör',
];