<?php 

return [
    'campaign' => 'kampanya',
    'locations' => 'kiralama-noktalari',
    'vehicles' => 'arac-filomuz',
    'news' => 'blog',
    'best_deals' => 'firsatlar',
    'legal_texts' => 'yasal-metinler',
];