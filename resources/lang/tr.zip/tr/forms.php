<?php 

return [
    'required' => 'Lütfen boş bırakmayın.',
];