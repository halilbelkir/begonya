<?php 

return [
    'havalimani_subeleri' => 'Sixt havalimanı şubeleri',
    'sehirici_subeleri' => 'Sixt şehiriçi şubeleri',
    'phone' => 'Çağrı Merkezi',
    'hafta_ici' => 'Hafta içi',
    'cumartesi' => 'Cumartesi',
    'pazar' => 'Pazar',
    'alis' => 'ALIŞ',
    'donus' => 'DÖNÜŞ',
    'degistir' => 'Değiştir',
    'alis_tarih_saat' => 'ALIŞ TARİHİ SAAT',
    'donus_tarih_saat' => 'VERİŞ TARİHİ SAAT',
    'calisma_saatleri' => 'Çalışma Satleri',
    'placeholder' => 'Şehir, Havalimanı, Araç Kiralama',
    'verisyeri' => 'DÖNÜŞ İSTASYONU',
    'devam' => 'DEVAM ET',
    'devam_et' => 'DEVAM ET',
];