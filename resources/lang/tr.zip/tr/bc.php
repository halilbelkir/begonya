<?php 

return [
    'tebrik' => 'Tebrikler, mükemmel seçim!',
    'rez_alindi' => 'Rezervasyonunuz Alınmıştır.',
    'onay_maili_text' => 'Kısa bir süre içinde onay mailini alacaksınız.',
    'rez_no' => 'Rezervasyon Numaranız:',
    'toplam' => 'Toplam Tutar:',
    'iyi_yolculuklar' => 'İyi Yolculuklar',
    'onemli_bilgiler' => 'Araç alımına ilişkin önemli bilgiler',
    'asagidaki_belgeleri_saglayin' => 'Aracınızı alırken lütfen aşağıdaki belgeleri sağlayın.',
    'asagidaki_belgeler' => 'Sürücü adına verilen aşağıdaki ödeme yöntemlerinden biri:',
    'dipnot' => 'Burada gösterilen araçlar, söz konusu gruplar için örnek teşkil etmektedir. Malesef size kesin bir marka veya model taahhüt edemiyoruz. Kiralanacak aracın markası ve modeli kiralama saatindeki uygunluk durumuna göre söz konusu gruba dahil araçlardan biri olarak yetkililerce belirlenecektir.',
];