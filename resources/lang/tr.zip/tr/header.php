<?php 

return [
    'kiralama_detay' => 'KİRALAMA DETAY',
    'arac_secimi' => 'ARAÇ SEÇİMİ',
    'ucret_ekstra' => 'ÜCRET&EKSTRA',
    'surucu_detay' => 'SÜRÜCÜ DETAY',
];